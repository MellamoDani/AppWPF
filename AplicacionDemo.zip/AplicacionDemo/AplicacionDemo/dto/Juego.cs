﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplicacionDemo.dto
{
    public class Juego : INotifyPropertyChanged, ICloneable, IDataErrorInfo
    {
        private String titulo;
        public String Titulo
        { 
            get 
            { 
                return titulo; 
            } 
            set
            {
                titulo= value;
                this.PropertyChanged(this, new PropertyChangedEventArgs("Titulo"));
            } 
        }

        private int puntuacion;
        public int Puntuacion
        {
            get
            {
                return puntuacion;
            }
            set 
            { 
                puntuacion= value;
                this.PropertyChanged(this, new PropertyChangedEventArgs("Puntuacion"));
            }
        }

        private DateTime fechaEntrada;
        public DateTime FechaEntrada
        {
        get
            {
                return fechaEntrada;
            }
            set
            {
                fechaEntrada= value;
                this.PropertyChanged(this, new PropertyChangedEventArgs("FechaEntrada"));
            }
        }

        public string Error
        {
            get { return "";  }
        }

        public string this[string columnName]
        {
            get 
            {
                string result = "";
                if (columnName == "Titulo")
                {
                    if (string.IsNullOrEmpty(titulo))
                    {
                        result = "Debe introducir el titulo";
                    }
                }
                if (columnName == "Puntuacion")
                {
                    if (puntuacion >= 0 && puntuacion <= 10 ) 
                    {
                        result = "Debe introducir la puntuacion";
                    }
                }
                return result;
            }
        }

        public Juego() 
        { 
            this.fechaEntrada = DateTime.Now;
        }

        public Juego(string titulo, int puntuacion, DateTime fechaEntrada)
        {
            this.titulo = titulo;
            this.puntuacion = puntuacion;
            this.fechaEntrada = fechaEntrada;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}
