﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AplicacionDemo.dto;

namespace AplicacionDemo.Logica
{
    public class LogicaNegocio
    {
        public ObservableCollection<Juego> listaJuegos { get; set; }

        public LogicaNegocio() 
        {
            listaJuegos = new ObservableCollection<Juego>();
            listaJuegos.Add(new Juego("MistBorn", 10, DateTime.Now));
        }

        public void aniadirJuego(Juego juego) 
        {
            listaJuegos.Add(juego);
        }

        public void modificarJuego(Juego libro, int posicion) 
        {
            listaJuegos[posicion] = libro;
        }
    }
}
