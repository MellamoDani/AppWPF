﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using AplicacionDemo.dto;
using AplicacionDemo.Logica;

namespace AplicacionDemo
{
    /// <summary>
    /// Lógica de interacción para DialogoJuego.xaml
    /// </summary>
    public partial class DialogoJuego : Window
    {
        private LogicaNegocio logicaNegocio;
        public Juego juego;
        private int posicion;
        private Boolean modificar;
        private int errores;
        public DialogoJuego(LogicaNegocio logicaNegocio)
        {
            InitializeComponent();
            this.logicaNegocio= logicaNegocio;
            juego = new Juego();
            this.DataContext= juego;
            modificar= false;
        }

        public DialogoJuego(LogicaNegocio logicaNegocio, Juego juegoModificar, int posicion)
        {
            InitializeComponent();
            this.logicaNegocio = logicaNegocio;
            this.juego = juegoModificar;
            this.posicion = posicion;
            this.DataContext = juego;
            modificar = true;
        }


        private void ButtonCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ButtonAceptar_Click(object sender, RoutedEventArgs e)
        {
            if (modificar)
            {
                logicaNegocio.modificarJuego(juego, posicion);
            }
            else
            {
                logicaNegocio.aniadirJuego(juego);
            }
            this.Close();
        }

        private void Validation_Error(object sender, ValidationErrorEventArgs e)
        {
            if (e.Action == ValidationErrorEventAction.Added)
            {
                errores++;
            }
            else
            {
                errores--;
            }
            if (errores == 0)
            {
                ButtonAceptar.IsEnabled = true;
            }
            else
            {
                ButtonAceptar.IsEnabled = false;
            }
        }

    }
}
